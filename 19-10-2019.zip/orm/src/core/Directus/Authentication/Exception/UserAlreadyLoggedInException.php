<?php

namespace Directus\Authentication\Exception;

use Directus\Exception\Exception;

class UserAlreadyLoggedInException extends Exception
{

}
