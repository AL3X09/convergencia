<?php

namespace Directus\Authentication\Exception;

use Directus\Exception\Exception;

class InvalidInvitationCodeException extends Exception
{

}
