<?php

return [
    'provider' => \Directus\Authentication\Sso\Provider\github\Provider::class
];
