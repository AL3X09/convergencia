<?php
class tbusuarios {
  public $id;
  public $nombres;
  public $apellidos;
  public $correo;
  public $localidad;
  public $usuario;
  public $contrasenia;
  public $imagen;
  public $estado;
  public $fecha;
}
